#' MPCurver package
#'
#' Estimate latent sample orderings, smooth feature trajectories, and
#' trajectory uncertainty using Gaussian measurement models and random-walk
#' priors. Multi-ordering models also estimate the probability that each
#' feature follows each ordering, using structural variational inference.
#' Start with \code{\link{fit_mpcurve}} and explore the results with
#' \code{\link{summary.mpcurve}} and \code{\link{plot.mpcurve}}.
#'
#' @name MPCurver
#' @keywords internal
#' @importFrom graphics abline arrows axis barplot box legend lines mtext par plot.new plot.window points rect text title
#' @importFrom stats as.dist cor optimize prcomp setNames var
#' @importFrom utils tail
"_PACKAGE"

#' Fitted MPCurve models
#'
#' An \code{mpcurve} object contains the sample positions, feature trajectories,
#' uncertainty estimates, and convergence diagnostics returned by
#' \code{\link{fit_mpcurve}} or \code{\link{do_mpcurve}}.
#' Use \code{\link{summary.mpcurve}} for a numerical summary and
#' \code{\link{plot.mpcurve}} to visualize trajectories and sample orderings.
#'
#' @section Sample positions:
#' For a single ordering, \code{$locations$mean$pseudotime} contains
#' posterior-mean positions on \eqn{[0,1]}, and
#' \code{$locations$map$pseudotime} contains positions at the most probable
#' grid component. For multiple orderings, \code{$locations} is a named list
#' with one such record per ordering. Pseudotime represents relative position
#' along an inferred trajectory; its direction can be reversed.
#'
#' @section Single-ordering objects:
#' For \code{intrinsic_dim = 1}, \code{$params$pi} is a length-\code{K}
#' position-prior vector, \code{$params$mu} is a \code{d x K} posterior-mean
#' trajectory matrix, \code{$params$sigma2} is a length-\code{d} estimated
#' variance vector (or \code{NULL} when measurement standard deviations are
#' supplied through \code{S}), and \code{$gamma} is the \code{n x K}
#' responsibility matrix. The full Gaussian trajectory posterior is available
#' from \code{$fit$posterior}. When \code{S} is supplied,
#' \code{$measurement_sd} stores either its length-\code{d} feature-shared
#' form or its \code{n x d} observation-level form.
#'
#' @section Multiple orderings and feature assignments:
#' For \code{intrinsic_dim = M >= 2}, the variational family is
#' \deqn{q(C)\prod_{j=1}^d q(Z_j)q(U_j\mid Z_j).}
#' Here \eqn{C} represents sample positions, \eqn{Z_j} the ordering followed
#' by feature \eqn{j}, and \eqn{U_j} its trajectory. The object contains:
#' \itemize{
#'   \item \code{$params$pi}: named list of \code{M} length-\code{K}
#'     position-prior vectors;
#'   \item \code{$params$mu}: named list of \code{M} \code{d x K}
#'     conditional posterior-mean matrices;
#'   \item \code{$params$sigma2}: one shared length-\code{d} estimated
#'     variance vector, or \code{NULL} for known measurement noise;
#'   \item \code{$gamma}: named list of \code{M} \code{n x K}
#'     position-responsibility matrices;
#'   \item \code{$measurement_sd}: \code{NULL} when noise is estimated, or the
#'     supplied length-\code{d} / \code{n x d} known-standard-deviation
#'     specification;
#'   \item \code{$conditional_posterior}: conditional Gaussian distributions for
#'     \eqn{q(U_j\mid Z_j=m)}. Each \code{$mean[[m]]} is \code{d x K};
#'     each \code{$cov[[m]][[j]]} is \code{K x K}; and
#'     \code{$var[[m]]} (also available as \code{$diag[[m]]}) is
#'     \code{d x K};
#'   \item \code{$lambda_mat}: a \code{d x M} matrix of smoothness
#'     parameters;
#'   \item \code{$partition$pi_weights}: a \code{d x M} matrix containing
#'     \eqn{q(Z_j=m)}, with the hard display assignment in
#'     \code{$partition$assign};
#'   \item \code{$objective_history} and \code{$temperature_history}: the
#'     variational objective and its temperature schedule. Use the
#'     \eqn{T=1} segment to assess convergence after annealing.
#' }
#' Each row of \code{$partition$pi_weights} sums to one. Concentrated rows
#' indicate strong support for an ordering; diffuse rows indicate uncertainty
#' about the feature assignment. Conditional trajectory means describe the
#' fitted shape under each possible assignment, so interpret them alongside
#' these probabilities.
#'
#' @section Additional fields:
#' \code{$fit} stores the underlying variational fit. For partition models,
#' \code{$fits} provides derived per-ordering views for inspection; continue
#' the complete model with \code{do_mpcurve(object)}. The dimension fields
#' \code{$intrinsic_dim}, \code{$active_intrinsic_dim}, and
#' \code{$displayed_intrinsic_dim} all equal the specified \code{M} for
#' structural partition fits. \code{$effective_intrinsic_dim} is the number
#' of orderings with nontrivial fitted assignment-prior weight under an
#' adaptive prior, using \code{effective_weight_tol}; it equals the fitted
#' \code{M} for a fixed prior. This count does not remove fitted orderings.
#' Fits returned by \code{\link{select_mpcurve_dimension}} also include
#' \code{$dimension_selection} with candidate scores and greedy decisions.
#'
#' @name mpcurve
#' @keywords models
NULL
