## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE,
  fig.width = 7,
  fig.height = 5
)

## ----load---------------------------------------------------------------------
library(MPCurver)
set.seed(42)

## ----simulate-----------------------------------------------------------------
sim <- simulate_dual_trajectory(
  n = 500,
  d1 = 10,
  d2 = 10,
  d_noise = 0,
  sigma = 0.05,
  trajectory_family = c("quadratic", "monotone"),
  seed = 1
)

X <- sim$X
truth <- sim$true_assign

## ----fit-soft-----------------------------------------------------------------
fit_partition <- fit_mpcurve(
  X,
  intrinsic_dim = 2,
  method = "PCA",
  K = 50,
  rw_q = 2,
  ridge = 0,
  verbose = FALSE
)

## ----assignment-probabilities-------------------------------------------------
head(fit_partition$partition$pi_weights)
table(fit_partition$partition$assign)

## ----accuracy-----------------------------------------------------------------
pred <- as.character(fit_partition$partition$assign)
truth <- as.character(truth)
accuracy <- max(mean(pred == truth), mean(pred != truth))
cat("Partition accuracy:", round(accuracy, 4), "\n")

## ----visualize-mpcurve, fig.cap="Variational objective over fitting iterations and observed feature values along each inferred ordering."----
plot(fit_partition, plot_type = "elbo")
plot(fit_partition, dims = 4)

## ----structural-mu-one-dimensional, fig.cap="Conditional mean trajectory of feature 4 under each ordering; panel titles report assignment probabilities."----
plot(fit_partition, plot_type = "mu", dims = 4)

## ----structural-mu-two-dimensional, fig.cap="Conditional mean paths for features 4 and 14 under each ordering."----
plot(fit_partition, plot_type = "mu", dims = c(4, 14))

## ----check-objective----------------------------------------------------------
t1_objective <- fit_partition$objective_history[
  fit_partition$temperature_history == 1
]
cat("Recorded T=1 objective values:", length(t1_objective), "\n")
cat("Final objective increments:\n")
tail(diff(t1_objective))

## ----continue, eval=FALSE-----------------------------------------------------
# fit_partition <- do_mpcurve(fit_partition, iter = 10)

## ----effective-dimension------------------------------------------------------
fit_partition$effective_intrinsic_dim
fitted_prior(fit_partition, type = "partition")$omega

## ----automatic-dimension, eval=FALSE------------------------------------------
# fit_auto <- fit_mpcurve(
#   X,
#   intrinsic_dim = "auto",
#   max_intrinsic_dim = 8,
#   similarity_metric = "spline_r2",
#   spline_r2_df = 5,
#   similarity_min_cluster_size = 2,
#   partition_prior = "adaptive",
#   K = 50,
#   verbose = FALSE
# )
# 
# fit_auto$intrinsic_dim
# fit_auto$effective_intrinsic_dim

## ----greedy-dimension, eval=FALSE---------------------------------------------
# selected <- select_mpcurve_dimension(
#   X,
#   max_intrinsic_dim = 4,
#   direction = "forward",
#   K = 20,
#   T_start = 1,
#   T_end = 1,
#   n_outer = 1,
#   max_converge_iter = 500
# )
# selected$effective_intrinsic_dim
# selected$dimension_selection$history

## ----fit-methods, eval=FALSE--------------------------------------------------
# fit3 <- fit_mpcurve(
#   X,
#   intrinsic_dim = 3,
#   partition_init = "ordering_methods",
#   method = c("fiedler", "PCA", "PCA"),
#   K = 16
# )

