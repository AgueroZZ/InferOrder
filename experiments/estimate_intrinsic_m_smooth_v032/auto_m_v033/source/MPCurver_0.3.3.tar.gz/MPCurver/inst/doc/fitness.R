## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE,
  fig.width = 8,
  fig.height = 5.5
)

## ----load---------------------------------------------------------------------
if (requireNamespace("MPCurver", quietly = TRUE)) {
  library(MPCurver)
} else if (requireNamespace("devtools", quietly = TRUE)) {
  devtools::load_all(".", quiet = TRUE)
} else {
  stop("Need either an installed MPCurver package or devtools::load_all().")
}

set.seed(42)

locate_elife_csv <- function() {
  pkg_path <- system.file("extdata", "elife-61271-fig2-data1-v2.csv", package = "MPCurver")
  if (nzchar(pkg_path) && file.exists(pkg_path)) {
    return(pkg_path)
  }

  src_path <- file.path("inst", "extdata", "elife-61271-fig2-data1-v2.csv")
  if (file.exists(src_path)) {
    return(src_path)
  }

  stop("Could not locate elife-61271-fig2-data1-v2.csv.")
}

csv_path <- locate_elife_csv()
dat <- read.csv(csv_path, check.names = FALSE)

fitness_cols <- grep("_fitness$", names(dat), value = TRUE)
error_cols <- grep("_error$", names(dat), value = TRUE)

X <- as.matrix(dat[, fitness_cols, drop = FALSE])
mode(X) <- "numeric"
colnames(X) <- sub("_fitness$", "", fitness_cols)

S <- as.matrix(dat[, error_cols, drop = FALSE])
mode(S) <- "numeric"
colnames(S) <- sub("_error$", "", error_cols)

meta <- dat[, c("barcode", "gene", "type", "ploidy", "class", "mutation_type"), drop = FALSE]

## ----adjust-se----------------------------------------------------------------
t_adjust_se <- function(Y, S, nu, tol = 1e-12) {
  if (!is.matrix(Y) || !is.numeric(Y)) {
    stop("`Y` must be a numeric matrix.")
  }
  if (!is.matrix(S) || !is.numeric(S)) {
    stop("`S` must be a numeric matrix.")
  }
  if (!all(dim(Y) == dim(S))) {
    stop("`Y` and `S` must have the same dimensions.")
  }
  if (any(S < 0, na.rm = TRUE)) {
    stop("`S` must be nonnegative.")
  }
  
  if (length(nu) == 1L) {
    if (!is.numeric(nu) || is.na(nu) || nu <= 0) {
      stop("`nu` must be a positive number.")
    }
    nu_mat <- matrix(nu, nrow = nrow(Y), ncol = ncol(Y))
  } else {
    if (!is.matrix(nu) || !is.numeric(nu) || !all(dim(nu) == dim(Y))) {
      stop("`nu` must be either a positive scalar or a numeric matrix with the same dimensions as `Y`.")
    }
    if (any(nu <= 0, na.rm = TRUE)) {
      stop("All entries of `nu` must be positive.")
    }
    nu_mat <- nu
  }
  
  z_t <- Y / S
  
  # Main calculation:
  # S_tilde = S * z_t / qnorm(pt(z_t, df = nu))
  p_t <- pt(z_t, df = nu_mat)
  z_n <- qnorm(p_t)
  
  S_tilde <- S * z_t / z_n
  
  # Numerical fix for z_t close to 0:
  # limit of z / qnorm(pt(z, df=nu)) as z -> 0 is dnorm(0) / dt(0, df=nu)
  near_zero <- is.finite(z_t) & abs(z_t) < tol
  if (any(near_zero, na.rm = TRUE)) {
    limit_factor <- dnorm(0) / dt(0, df = nu_mat[near_zero])
    S_tilde[near_zero] <- S[near_zero] * limit_factor
  }
  
  # Preserve zeros
  zero_se <- (S == 0) & !is.na(S)
  if (any(zero_se)) {
    S_tilde[zero_se] <- 0
  }
  
  dimnames(S_tilde) <- dimnames(S)
  S_tilde
}
S <- t_adjust_se(X, S, nu = 4)

## ----helpers, include=FALSE---------------------------------------------------
environment_category <- function(env) {
  if (grepl("Ferm|Day", env)) return("time course")
  if (grepl("NaCl|KCl", env)) return("salt stress")
  if (grepl("Ben|Flu|GdA|DMSO", env)) return("drug / chemical")
  if (grepl("Gluc|Baffle", env)) return("glucose / batch")
  if (grepl("Raf|Gly|EtOH|Suc", env)) return("carbon source")
  "other"
}

env_category <- vapply(colnames(X), environment_category, character(1))

plot_ordered_heatmap <- function(X, order_idx, env_idx = seq_len(ncol(X)),
                                 main = "", zlim = c(-2.5, 2.5)) {
  Xsub <- X[order_idx, env_idx, drop = FALSE]
  Xsub <- scale(Xsub)
  Xsub[!is.finite(Xsub)] <- 0
  pal <- colorRampPalette(c("#313695", "#74add1", "#f7f7f7", "#f46d43", "#a50026"))(101)
  image(
    x = seq_len(nrow(Xsub) + 1L),
    y = seq_len(ncol(Xsub) + 1L),
    z = Xsub,
    col = pal,
    axes = FALSE,
    xlab = "Mutants ordered by inferred pseudotime",
    ylab = "",
    zlim = zlim,
    main = main
  )
  axis(2, at = seq_len(ncol(Xsub)), labels = colnames(Xsub), las = 2, cex.axis = 0.55)
  box()
}


## ----data-summary-------------------------------------------------------------
data.frame(
  quantity = c("mutants", "environments", "fitness columns", "error columns"),
  value = c(nrow(X), ncol(X), length(fitness_cols), length(error_cols))
) |>
  knitr::kable()

sort(table(env_category), decreasing = TRUE) |>
  as.data.frame() |>
  stats::setNames(c("category", "n_environments")) |>
  knitr::kable()

## ----uni-fit------------------------------------------------------------------
fit_unidir <- fit_mpcurve(
  X,
  method = "isomap",
  K = 50,
  rw_q = 2,
  verbose = FALSE
)

## ----uni-convergence, out.width = "100%", fig.alt = "ELBO trace for the single-ordering CAVI fit, showing convergence over iterations."----
plot(fit_unidir, plot_type = "elbo")

## ----uni-trajectories, fig.height = 8, out.width = "100%", fig.alt = "Four panels showing fitted single-ordering CAVI trajectories for the first four environment dimensions."----
par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))
plot(fit_unidir, dims = 1)
plot(fit_unidir, dims = 2)
plot(fit_unidir, dims = 3)
plot(fit_unidir, dims = 4)
par(mfrow = c(1, 1))

## ----uni-fit-smooth-----------------------------------------------------------
fit_unidir_smooth <- fit_mpcurve(
  X,
  method = "isomap",
  K = 50,
  iter = 500,
  rw_q = 2,
  lambda_sd_prior_rate = 1e4,
  verbose = FALSE
)

## ----uni-convergence-smooth, out.width = "100%", fig.alt = "ELBO trace for the smoothed single-ordering CAVI fit."----
plot(fit_unidir_smooth, plot_type = "elbo")
fit_unidir_smooth

## ----uni-trajectories-smooth, fig.height = 8, out.width = "100%", fig.alt = "Four panels showing fitted trajectories under the smoothed single-ordering CAVI fit."----
par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))
plot(fit_unidir_smooth, dims = 1)
plot(fit_unidir_smooth, dims = 3)
plot(fit_unidir_smooth, dims = 7)
plot(fit_unidir_smooth, dims = 9)
par(mfrow = c(1, 1))

## ----compare-single-orderings, out.width = "100%", fig.alt = "Scatter plot comparing inferred mutant pseudotime between the default and smoothed single-ordering fits."----
cor(
  fit_unidir_smooth$locations$mean$pseudotime,
  fit_unidir$locations$mean$pseudotime
)

plot(
  fit_unidir_smooth$locations$mean$pseudotime,
  fit_unidir$locations$mean$pseudotime,
  xlab = "Latent position (smoother fit)",
  ylab = "Latent position (less regularized fit)"
)
abline(0, 1, lty = 2)

## ----partition-fit------------------------------------------------------------
fit_partition <- fit_mpcurve(
  X,
  method = "isomap",
  intrinsic_dim = 2,
  ridge = 0,
  K = 50,
  iter = 500,
  rw_q = 2,
  lambda_sd_prior_rate = 1e4,
  verbose = FALSE
)

## ----partition-summary--------------------------------------------------------
fit_partition

## ----partition-plot, out.width = "100%", fig.alt = "Conditional posterior mean trajectory for environment dimension 1 under each of two fixed orderings."----
plot(fit_partition, plot_type = "mu", dims = 1)

## ----partition-table----------------------------------------------------------
assignment_tbl <- data.frame(
  environment = colnames(X),
  category = env_category,
  ordering = fit_partition$partition$assign,
  stringsAsFactors = FALSE
)

assignment_tbl[order(assignment_tbl$ordering, assignment_tbl$category, assignment_tbl$environment), ] |>
  knitr::kable(row.names = FALSE)

## ----partition-correlation----------------------------------------------------
ordering_names <- names(fit_partition$locations)
ordering_names <- ordering_names[ordering_names %in% unique(fit_partition$partition$assign)]

t_df <- setNames(
  as.data.frame(lapply(ordering_names, function(nm) {
    fit_partition$locations[[nm]]$mean$pseudotime
  })),
  ordering_names
)

cor(t_df) |>
  knitr::kable(digits = 3)

## ----uni-fit-known-sd---------------------------------------------------------
fit_unidir_known_sd <- fit_mpcurve(
  X,
  S = S,
  method = "isomap",
  K = 50,
  iter = 500,
  rw_q = 2,
  lambda_sd_prior_rate = 1e4,
  verbose = FALSE
)

## ----uni-known-sd-convergence, out.width = "100%", fig.alt = "ELBO trace for the single-ordering CAVI fit with known measurement standard deviations."----
plot(fit_unidir_known_sd, plot_type = "elbo")

## ----uni-known-sd-trajectories, fig.height = 8, out.width = "100%", fig.alt = "Four panels showing fitted trajectories for the single-ordering CAVI fit with known measurement SDs."----
par(mfrow = c(2, 2), mar = c(4, 4, 3, 1))
plot(fit_unidir_known_sd, dims = 1)
plot(fit_unidir_known_sd, dims = 2)
plot(fit_unidir_known_sd, dims = 31)
plot(fit_unidir_known_sd, dims = 45)
par(mfrow = c(1, 1))

## ----partition-fit-known-sd---------------------------------------------------
fit_partition_known_sd <- fit_mpcurve(
  X,
  S = S,
  method = "isomap",
  intrinsic_dim = 2,
  ridge = 0,
  K = 50,
  iter = 500,
  rw_q = 2,
  lambda_sd_prior_rate = 1e4,
  verbose = FALSE
)

fit_partition_known_sd

## ----known-sd-partition-trajectories, fig.height = 5.5, out.width = "100%", fig.alt = "Conditional posterior mean trajectory for environment dimension 31 under each of two fixed orderings with known measurement SDs."----
plot(fit_partition_known_sd, plot_type = "mu", dims = 31)

