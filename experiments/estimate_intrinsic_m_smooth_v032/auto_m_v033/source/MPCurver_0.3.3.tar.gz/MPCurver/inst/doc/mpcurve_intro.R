## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>",
  message = FALSE,
  warning = FALSE,
  fig.width = 7,
  fig.height = 5
)

## ----load---------------------------------------------------------------------
library(MPCurver)
set.seed(42)

## ----simulate-----------------------------------------------------------------
sim <- simulate_swiss_roll_1d_2d(
  n = 1000,
  t_range = c(1.5 * pi, 4.5 * pi),
  sigma = 0.12,
  seed = 1
)

X <- as.matrix(sim$obs)
t_true <- sim$t

cat("Data dimensions:", nrow(X), "x", ncol(X), "\n")
cat("t range:", round(range(t_true), 3), "\n")

## ----plot-data, fig.cap="Simulated spiral observations, colored by the generating latent position."----
pal <- grDevices::colorRampPalette(
  c("#1F3A5F", "#2E8A99", "#F2C14E", "#E76F51")
)(256)
col_true <- pal[cut(t_true, breaks = 256, labels = FALSE)]

plot(X, col = col_true, pch = 19, cex = 0.55,
     xlab = "x", ylab = "y",
     main = "Observed spiral, coloured by true pseudotime")

## ----fit-cavi-----------------------------------------------------------------
fit <- fit_mpcurve(
  X,
  method = "fiedler",
  K = 60,
  iter = 120
)

stopifnot(inherits(fit, "mpcurve"))
stopifnot(identical(fit$algorithm, "cavi"))

fit

## ----summary-fit--------------------------------------------------------------
summary(fit)

## ----check-elbo---------------------------------------------------------------
stopifnot(all(diff(fit$elbo_trace) >= -1e-8))
cat("ELBO monotone:", TRUE, "\n")
cat("ELBO range:", round(range(fit$elbo_trace), 3), "\n")

## ----ordering-recovery--------------------------------------------------------
pseudotime_hat <- as.numeric(fit$gamma %*% seq_len(ncol(fit$gamma)))
rho_t <- abs(cor(pseudotime_hat, t_true, method = "spearman"))

cat("Absolute Spearman correlation with true t:", round(rho_t, 4), "\n")

## ----plot-fit, fig.cap="True pseudotime (left) and inferred CAVI pseudotime (right)."----
col_fit <- pal[cut(pseudotime_hat, breaks = 256, labels = FALSE)]

op <- par(mfrow = c(1, 2), mar = c(4, 4, 2.5, 1))
plot(X, col = col_true, pch = 19, cex = 0.5,
     xlab = "x", ylab = "y", main = "Truth")
plot(X, col = col_fit, pch = 19, cex = 0.5,
     xlab = "x", ylab = "y", main = "CAVI fit")
par(op)

## ----plot-trace, fig.cap="CAVI trace plot from the fitted mpcurve object."----
plot(fit, plot_type = "elbo")

## ----plot-mu, fig.cap="Posterior mean trajectories across the K bins."--------
plot(fit, plot_type = "mu")

