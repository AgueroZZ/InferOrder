# print.mpcurve is shorter than summary for single and partition fits

    MPCurve fit
      Backend        : cavi
      Model          : homoskedastic
      Intrinsic dim  : 1
      n / d / K      : 60 / 8 / 5
      Iterations     : 4
      Converged      : no
      ELBO (last)    : 94.808050

---

    MPCurve partition fit
      Backend        : cavi
      Variational    : structural q(C) q(Z) q(U | Z)
      Intrinsic dim  : 2
      n / d / K      : 60 / 8 / 6
      Iterations     : 4
      Partition      : A=3, B=5
      Objective (last): -582.299828
      Converged      : FALSE

